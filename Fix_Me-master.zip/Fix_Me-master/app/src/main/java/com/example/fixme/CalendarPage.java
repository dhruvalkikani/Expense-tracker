package com.example.fixme;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

/**
 * Calendar pagse
 */

public class CalendarPage extends AppCompatActivity {
    /**
     * displays the Calendar page
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar_page);


    }
}
